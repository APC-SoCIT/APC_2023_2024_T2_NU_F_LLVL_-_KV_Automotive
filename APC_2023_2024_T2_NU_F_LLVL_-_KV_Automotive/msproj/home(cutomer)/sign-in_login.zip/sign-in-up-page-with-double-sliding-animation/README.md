# sign in/up page with double sliding animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aniketx27/pen/VNXQpL](https://codepen.io/aniketx27/pen/VNXQpL).

A beautiful sign in/up page with double sliding animation made in CSS, HTML and JS